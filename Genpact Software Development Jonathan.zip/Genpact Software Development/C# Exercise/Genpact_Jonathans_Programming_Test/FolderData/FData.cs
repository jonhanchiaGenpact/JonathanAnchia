﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Genpact_Jonathans_Programming_Test.FolderData
{
    public abstract class FData
    {

    }
}
