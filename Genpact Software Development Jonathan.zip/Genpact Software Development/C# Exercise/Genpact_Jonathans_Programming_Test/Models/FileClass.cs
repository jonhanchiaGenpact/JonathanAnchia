﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Application = Microsoft.Office.Interop.Excel.Application;
using Workbook = Microsoft.Office.Interop.Excel.Workbook;
using Worksheet = Microsoft.Office.Interop.Excel.Worksheet;
namespace Genpact_Jonathans_Programming_Test.Models
{
    public class FileClass
    {
        
        public int NumFiles { get; private set; }
        public int NumExcelFiles { get; private set; }
        public int NumOtherFiles { get; private set; }
        string fPath;

        public FileClass()
        {
            //Constructor
        }

        private void GetFileAnalisys() {

            NumFiles = 0;
            NumExcelFiles = 0;
            NumOtherFiles = 0;

            NumExcelFiles = NumExcelFiles / NumFiles;
            NumOtherFiles = NumOtherFiles / NumFiles;
            
        }
        public void LoadFileWatcherData(string fPath) {

            GetFileAnalisys();

        }
        public void FileConsolidation(string sourcePath, string destPath) {
            int dd = DateTime.Now.Day;
            int hour = DateTime.Now.Hour;
            int minute = DateTime.Now.Minute;
            long seconds = DateTime.Now.Second;
            MessageBox.Show("Consolidating Excel files");
            DirectoryInfo d = new DirectoryInfo(sourcePath);
            FileInfo[] Files = d.GetFiles("*", SearchOption.TopDirectoryOnly);

            List<string> rawFilesDirectory = new List<string>();
            foreach (FileInfo file in Files)
            {
                rawFilesDirectory.Add(file.FullName);
            }

            Application app = new Application();
            app.Visible = false;
            for (int i = 0; i < rawFilesDirectory.Count; i++)
            {
                Workbook wb = app.Workbooks.Add(rawFilesDirectory[i]);
            }
            for (int i = 2; i <= app.Workbooks.Count; i++)
            {
                for (int j = 1; j <= app.Workbooks[i].Worksheets.Count; j++)
                {
                    Worksheet ws = (Worksheet)app.Workbooks[i].Worksheets[j];
                    ws.Copy(app.Workbooks[1].Worksheets[1]);
                }
            }
            app.Workbooks[1].SaveCopyAs(destPath + "\\" + dd.ToString() + " at " + hour.ToString() + "_" + minute.ToString() + "_" + seconds.ToString() + ".xls");
            for (int i = 1; i < app.Workbooks.Count; i++)
            {
                app.Workbooks[i].Close(0);
            }
            app.Quit();
            MessageBox.Show("Completed, you can find the lastest master file in:" + destPath);
        }
      
       
    }
 }




