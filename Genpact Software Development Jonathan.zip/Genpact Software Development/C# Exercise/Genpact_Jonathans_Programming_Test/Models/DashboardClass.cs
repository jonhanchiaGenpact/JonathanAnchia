﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Application = Microsoft.Office.Interop.Excel.Application;
using Workbook = Microsoft.Office.Interop.Excel.Workbook;
using Worksheet = Microsoft.Office.Interop.Excel.Worksheet;


namespace Genpact_Jonathans_Programming_Test.Models
{
    class DashboardClass
    {
       
        public int NumExcelFiles { get; private set; }
        public int NumOtherFiles { get; private set; }
        public DashboardClass()
        {
            //Constructor
        }
        public void DashBoardGraph(int naFiles,  int totalFiles)
        {
            
            NumOtherFiles = naFiles - totalFiles;

        }
        public void DashBoardGrapchPr(int prFiles, int totalFiles) {
            NumExcelFiles = prFiles - totalFiles;
        }
    }
}
