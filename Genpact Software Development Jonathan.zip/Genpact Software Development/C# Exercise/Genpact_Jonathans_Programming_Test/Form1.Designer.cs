﻿
namespace Genpact_Jonathans_Programming_Test
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPath = new System.Windows.Forms.Label();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblFWatcher = new System.Windows.Forms.Label();
            this.lblConsolidation = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCalcDash = new System.Windows.Forms.Button();
            this.btnFStop = new System.Windows.Forms.Button();
            this.btnGetFolderLocation = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblXls = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblNonXls = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.FileWatcher = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FileWatcher)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(52)))), ((int)(((byte)(92)))));
            this.panel1.Controls.Add(this.lblPath);
            this.panel1.Controls.Add(this.btnMinimize);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.lblFWatcher);
            this.panel1.Controls.Add(this.lblConsolidation);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 55);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // lblPath
            // 
            this.lblPath.AutoSize = true;
            this.lblPath.ForeColor = System.Drawing.Color.White;
            this.lblPath.Location = new System.Drawing.Point(149, 30);
            this.lblPath.Name = "lblPath";
            this.lblPath.Size = new System.Drawing.Size(0, 16);
            this.lblPath.TabIndex = 7;
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.Color.Transparent;
            this.btnMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimize.Image")));
            this.btnMinimize.Location = new System.Drawing.Point(769, 12);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(36, 34);
            this.btnMinimize.TabIndex = 6;
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Transparent;
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Location = new System.Drawing.Point(811, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(36, 34);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblFWatcher
            // 
            this.lblFWatcher.AutoSize = true;
            this.lblFWatcher.ForeColor = System.Drawing.Color.White;
            this.lblFWatcher.Location = new System.Drawing.Point(56, 30);
            this.lblFWatcher.Name = "lblFWatcher";
            this.lblFWatcher.Size = new System.Drawing.Size(61, 16);
            this.lblFWatcher.TabIndex = 3;
            this.lblFWatcher.Text = "File Watcher";
            // 
            // lblConsolidation
            // 
            this.lblConsolidation.AutoSize = true;
            this.lblConsolidation.ForeColor = System.Drawing.Color.White;
            this.lblConsolidation.Location = new System.Drawing.Point(56, 12);
            this.lblConsolidation.Name = "lblConsolidation";
            this.lblConsolidation.Size = new System.Drawing.Size(87, 16);
            this.lblConsolidation.TabIndex = 2;
            this.lblConsolidation.Text = "Consolidation Tool";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 34);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.btnCalcDash);
            this.panel2.Controls.Add(this.btnFStop);
            this.panel2.Controls.Add(this.btnGetFolderLocation);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 55);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(131, 399);
            this.panel2.TabIndex = 1;
            // 
            // btnCalcDash
            // 
            this.btnCalcDash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(52)))), ((int)(((byte)(92)))));
            this.btnCalcDash.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcDash.FlatAppearance.BorderSize = 0;
            this.btnCalcDash.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcDash.Location = new System.Drawing.Point(0, 112);
            this.btnCalcDash.Name = "btnCalcDash";
            this.btnCalcDash.Size = new System.Drawing.Size(131, 23);
            this.btnCalcDash.TabIndex = 6;
            this.btnCalcDash.Text = "Dashboard Data";
            this.btnCalcDash.UseVisualStyleBackColor = false;
            this.btnCalcDash.Click += new System.EventHandler(this.btnCalcDash_Click);
            // 
            // btnFStop
            // 
            this.btnFStop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(52)))), ((int)(((byte)(92)))));
            this.btnFStop.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnFStop.FlatAppearance.BorderSize = 0;
            this.btnFStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFStop.Location = new System.Drawing.Point(0, 83);
            this.btnFStop.Name = "btnFStop";
            this.btnFStop.Size = new System.Drawing.Size(131, 23);
            this.btnFStop.TabIndex = 5;
            this.btnFStop.Text = "Stop Folder Watcher";
            this.btnFStop.UseVisualStyleBackColor = false;
            this.btnFStop.Click += new System.EventHandler(this.btnFStop_Click);
            // 
            // btnGetFolderLocation
            // 
            this.btnGetFolderLocation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(52)))), ((int)(((byte)(92)))));
            this.btnGetFolderLocation.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnGetFolderLocation.FlatAppearance.BorderSize = 0;
            this.btnGetFolderLocation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGetFolderLocation.Location = new System.Drawing.Point(0, 54);
            this.btnGetFolderLocation.Name = "btnGetFolderLocation";
            this.btnGetFolderLocation.Size = new System.Drawing.Size(131, 23);
            this.btnGetFolderLocation.TabIndex = 4;
            this.btnGetFolderLocation.Text = "Select Folder";
            this.btnGetFolderLocation.UseVisualStyleBackColor = false;
            this.btnGetFolderLocation.Click += new System.EventHandler(this.btnGetFolderLocation_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(131, 55);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(726, 146);
            this.panel3.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(98)))), ((int)(((byte)(99)))));
            this.panel6.Controls.Add(this.lblTotal);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Location = new System.Drawing.Point(491, 17);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 100);
            this.panel6.TabIndex = 2;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Oswald", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(52, 50);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 24);
            this.lblTotal.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Oswald", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(33, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "Total files in the directory";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(52)))), ((int)(((byte)(92)))));
            this.panel5.Controls.Add(this.lblXls);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Location = new System.Drawing.Point(266, 17);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 100);
            this.panel5.TabIndex = 1;
            // 
            // lblXls
            // 
            this.lblXls.AutoSize = true;
            this.lblXls.Font = new System.Drawing.Font("Oswald", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXls.ForeColor = System.Drawing.Color.White;
            this.lblXls.Location = new System.Drawing.Point(51, 50);
            this.lblXls.Name = "lblXls";
            this.lblXls.Size = new System.Drawing.Size(0, 24);
            this.lblXls.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Oswald", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(32, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Quantity of  Excel files";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(171)))), ((int)(((byte)(202)))));
            this.panel4.Controls.Add(this.lblNonXls);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(36, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 100);
            this.panel4.TabIndex = 0;
            // 
            // lblNonXls
            // 
            this.lblNonXls.AutoSize = true;
            this.lblNonXls.Font = new System.Drawing.Font("Oswald", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonXls.ForeColor = System.Drawing.Color.White;
            this.lblNonXls.Location = new System.Drawing.Point(50, 50);
            this.lblNonXls.Name = "lblNonXls";
            this.lblNonXls.Size = new System.Drawing.Size(0, 24);
            this.lblNonXls.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Oswald", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(31, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Quantity of non Excel files";
            // 
            // FileWatcher
            // 
            chartArea1.Name = "ChartArea1";
            this.FileWatcher.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.FileWatcher.Legends.Add(legend1);
            this.FileWatcher.Location = new System.Drawing.Point(286, 215);
            this.FileWatcher.Name = "FileWatcher";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.IsValueShownAsLabel = true;
            series1.LabelForeColor = System.Drawing.Color.White;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.FileWatcher.Series.Add(series1);
            this.FileWatcher.Size = new System.Drawing.Size(394, 221);
            this.FileWatcher.TabIndex = 3;
            this.FileWatcher.Text = "FileWatcher";
            title1.Alignment = System.Drawing.ContentAlignment.TopLeft;
            title1.Font = new System.Drawing.Font("Oswald", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title1.Name = "Title1";
            title1.Text = "File Watcher";
            this.FileWatcher.Titles.Add(title1);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(857, 454);
            this.Controls.Add(this.FileWatcher);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Oswald", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FileWatcher)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblFWatcher;
        private System.Windows.Forms.Label lblConsolidation;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataVisualization.Charting.Chart FileWatcher;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnGetFolderLocation;
        private System.Windows.Forms.Label lblPath;
        private System.Windows.Forms.Button btnFStop;
        private System.Windows.Forms.Button btnCalcDash;
        private System.Windows.Forms.Label lblNonXls;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblXls;
        private System.Windows.Forms.Label label3;
    }
}

