﻿using Genpact_Jonathans_Programming_Test.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;




namespace Genpact_Jonathans_Programming_Test
{
    public partial class Form1 : Form
    {
        private FileClass model;
        public string fPath;
        int fCount;
        int fCountPr;
        int fCountNa;
        int mov;
        int movX;
        int movY;
        string []files;
        string extension;
        string dirP;
        string dirPT;
        string dirNa;
        string fileName;
        FileClass fileC = new FileClass();
        DashboardClass dashb = new DashboardClass();
        public Form1()
        {
            InitializeComponent();
        }

  
        private void btnGetFolderLocation_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fBrowser = new FolderBrowserDialog();
            OpenFileDialog fDialog = new OpenFileDialog();
            if (fBrowser.ShowDialog() == DialogResult.OK) {

                //fPath = Directory.GetDirectories(fBrowser.SelectedPath);
                fPath = fBrowser.SelectedPath;
                lblPath.Text = fPath;

                //tTopDirectory only needed
                fCount = Directory.GetFiles(fPath, "*", SearchOption.TopDirectoryOnly).Length;
                files = Directory.GetFiles(fPath, "*", SearchOption.TopDirectoryOnly);
                extension = Path.GetExtension(fPath);
                //Folder for processed excel files
                dirP = fPath + @"\" + "Processed";
                //Folder for not applicable files
                dirNa = fPath + @"\" + "Not applicable";
                //If there are no folder to save the NA and processed, create those
                if (!Directory.Exists(dirP)) {
                    
                    Directory.CreateDirectory(dirP);
                } 
                else if (!Directory.Exists(dirNa)) { 
                
                    Directory.CreateDirectory(dirNa);
                }

                //Only watch xls files
                FileSystemWatcher fsw = new FileSystemWatcher(fPath);
                fsw.IncludeSubdirectories = false;
                fsw.NotifyFilter = NotifyFilters.LastWrite;
                fsw.Changed += new FileSystemEventHandler(fsw_Changed);
                fsw.EnableRaisingEvents = true;
                fsw.Dispose();

                }

            }

        private void Form1_Load(object sender, EventArgs e)
        {

            string[] files;
            string fPath;
            Form1 form1 = new Form1();
            FolderBrowserDialog fBrowser = new FolderBrowserDialog();
            OpenFileDialog fDialog = new OpenFileDialog();
            if (fBrowser.ShowDialog() == DialogResult.OK)
            {
                fPath = fBrowser.SelectedPath;
                //Get the path from the label to use in multiple instances
                lblPath.Text = fPath;
                //string wathcedFolder = System.IO.Path.Combine("username");
                FileSystemWatcher fsw = new FileSystemWatcher(fPath);
                //Auhtorize to enable the event handler only in the top direcrtory selected.
                fsw.IncludeSubdirectories = false;
                fsw.NotifyFilter = NotifyFilters.LastWrite;
                fsw.Changed += new FileSystemEventHandler(fsw_Changed);
                fsw.EnableRaisingEvents = true;
            }
            

            
    }
        void fsw_Changed(object sender, FileSystemEventArgs e)
        {
            
            
            //MessageBox.Show("There is a change in the selected folder");
            String labeltest;
            labeltest = lblPath.Text;
            fCount = Directory.GetFiles(labeltest, "*", SearchOption.TopDirectoryOnly).Length;
            files = Directory.GetFiles(labeltest, "*", SearchOption.TopDirectoryOnly);
            extension = Path.GetExtension(labeltest);
            dirP = labeltest + @"\" + "Processed";
            dirPT = labeltest + @"\" + "Processed" + @"\" + "Master Books";
            dirNa = labeltest + @"\" + "Not applicable";
            try
            {
                if (!Directory.Exists(dirP))
                {

                    Directory.CreateDirectory(dirP);
                }
                else if (!Directory.Exists(dirNa))
                {

                    Directory.CreateDirectory(dirNa);
                }
                else if (!Directory.Exists(dirPT))
                {

                    Directory.CreateDirectory(dirPT);
                }
                foreach (var i in files)
                {
                    extension = Path.GetExtension(i);
                    //MessageBox.Show(extension);
                    //MessageBox.Show(labeltest);
                    fileName = Path.GetFileName(i.ToString());
                    //MessageBox.Show(fileName);
                    //MessageBox.Show(extension);
                    if (extension == ".xls")
                    {
                        System.IO.File.Move(i, dirP + @"\" + fileName);
                    }
                    else
                    {
                        //MessageBox.Show(i);
                        System.IO.File.Move(i, dirNa + @"\" + fileName);

                    }
                }

                fileC.FileConsolidation(dirP, dirPT);
            }
            catch (IOException) { 
            
            }
        }

        private void btnFStop_Click(object sender, EventArgs e)
        {
            String labeltest;
            labeltest = lblPath.Text;
            FileSystemWatcher fsw = new FileSystemWatcher(labeltest);
            fsw.EnableRaisingEvents = false;
        }

        private void btnCalcDash_Click(object sender, EventArgs e)
        {
            String labeltest;
            labeltest = lblPath.Text;
            dirP = labeltest + @"\" + "Processed";
            dirPT = labeltest + @"\" + "Processed" + @"\" + "Master Books";
            dirNa = labeltest + @"\" + "Not applicable";
            fCount = Directory.GetFiles(labeltest, "*", SearchOption.AllDirectories).Length;
            fCountPr = Directory.GetFiles(dirP, "*", SearchOption.TopDirectoryOnly).Length;
            fCountNa = Directory.GetFiles(dirNa, "*", SearchOption.TopDirectoryOnly).Length;
            dashb.DashBoardGraph(fCountNa, fCount);
            dashb.DashBoardGrapchPr(fCountPr, fCount);
            //Series Design
            lblNonXls.Text = fCountNa.ToString();
            lblTotal.Text = fCount.ToString();
            lblXls.Text = fCountPr.ToString();
            FileWatcher.Series["Series1"].Points.AddXY("1", fCountPr);
            FileWatcher.Series["Series1"].Points.AddXY("2", fCountNa);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1) {
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }
    }
    }

